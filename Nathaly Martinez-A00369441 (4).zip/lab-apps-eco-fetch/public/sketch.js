let canvas;
let URL = 'https://catfact.ninja/fact'
let URL1 = 'https://dog.ceo/api/breeds/image/random'
let URL2 = 'https://datausa.io/api/data?drilldowns=Nation&measures=Population'
let URL3 = 'https://api.coindesk.com/v1/bpi/currentprice.json'
let URL4 = 'https://randomuser.me/api/'

let catFact = null;
let dogCeo = null;
let dataUsa = null;
let bitCoin = null;
let randomUser = null;
let imagesDogs;
let order = 0;

function setup() {
    frameRate(60);
    canvas = createCanvas(windowWidth, windowHeight);
    canvas.style('z-index', '-1');
    canvas.style('position', 'fixed');
    canvas.style('top', '0');
    canvas.style('right', '0');
    
   
    fetch(URL)
    .then(response => response.json())
    .then(data => {catFact=data
        console.log(catFact.fact)})

    fetch(URL1)
    .then(response => response.json())
    .then(data => {dogCeo = data
    console.log(dogCeo.message)
imagesDogs = loadImage (dogCeo.message)})

    fetch(URL2)
    .then(response => response.json())
    .then(data => {dataUsa = data
    console.log(dataUsa.data)})

    fetch(URL3)
    .then(response => response.json())
    .then(data => {bitCoin = data
    console.log(bitCoin)})
}

function draw() {
    //background(0, 50);
    background(0);
    newCursor();
    if(catFact != null){

    textSize(20);
    textWrap(WORD);
    text(catFact.fact, 50, 50, 300);
    }
    if(dogCeo != null){
        image (imagesDogs, 70, 400, 350, 350);
    }
    if(dataUsa != null){
        textSize(20);
        textWrap(WORD);
        text(dataUsa.data[order]["ID Nation"],400,90,300);
        text(dataUsa.data[order].Nation,400,120,300);
        text(dataUsa.data[order].Population,400,150,300);
        text(dataUsa.data[order].Year,400,180,300);
    }

    if(bitCoin != null){
        textSize(20);
        textWrap(WORD);
        text(bitCoin.bpi.EUR.code,700,90,500);
        text(bitCoin.bpi.EUR.rate,700,120,300);
        text(bitCoin.bpi.USD.code,700,165,300);
        text(bitCoin.bpi.USD.rate,700,195,300);
        text(bitCoin.bpi.GBP.code,700,240,300);
        text(bitCoin.bpi.GBP.rate,700,270,300);
    }
}


function keyPressed() {
    if(key.toLocaleLowerCase() === 'a'){
        console.log('holii')

  fetch(URL)
  .then(response => response.json())
  .then(data => {catFact=data
    console.log(catFact.fact)})
  
  }
  if(key.toLocaleLowerCase() === 'b'){
    console.log('por fin diosito')

    fetch(URL1)
    .then(response => response.json())
    .then(data => {dogCeo=data;
    imagesDogs = loadImage(dogCeo.message)
console.log(dogCeo.message)})
  }
if(key.toLocaleLowerCase() === 'c'){
    if(order <=7){
        order ++
    }
    if(order ===7){
        order = 0;
    }
    console.log('si sirvo')

    fetch(URL2)
    .then(response => response.json())
    .then(data => {dataUsa=data
        console.log(dataUsa.data)})
}
}
function mouseClicked(){
 
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

function newCursor() {
    noStroke();
    fill(255);
    ellipse(pmouseX, pmouseY, 10, 10);
}

